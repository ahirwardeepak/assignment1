import React from "react";
import { useLocation, useNavigate } from "react-router-dom";

export default function Success() {
  const { state } = useLocation();
  const navigate = useNavigate();

  if (!state) {
    return (
      <div>
        <h2>No data submitted.</h2>
        <button onClick={() => navigate("/")}>Go back</button>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: "600px", margin: "auto" }}>
      <h2>Form Submitted Successfully</h2>
      <ul>
        {Object.entries(state).map(([key, value]) => (
          <li key={key}>
            <strong>{key}: </strong> {value}
          </li>
        ))}
      </ul>
      <button onClick={() => navigate("/")}>Back to Form</button>
    </div>
  );
}
