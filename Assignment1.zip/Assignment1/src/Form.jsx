import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const countries = {
  India: ["Delhi", "Mumbai", "Bangalore"],
  USA: ["New York", "Los Angeles", "Chicago"],
  Canada: ["Toronto", "Vancouver", "Montreal"]
};

export default function Form() {
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    username: "",
    email: "",
    password: "",
    phoneCode: "",
    phoneNumber: "",
    country: "",
    city: "",
    pan: "",
    aadhar: ""
  });

  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = () => {
    const newErrors = {};
    if (!form.firstName) newErrors.firstName = "First name is required";
    if (!form.lastName) newErrors.lastName = "Last name is required";
    if (!form.username) newErrors.username = "Username is required";
    if (!form.email || !/\S+@\S+\.\S+/.test(form.email))
      newErrors.email = "Valid email required";
    if (!form.password || form.password.length < 6)
      newErrors.password = "Password must be at least 6 characters";
    if (!form.phoneCode) newErrors.phoneCode = "Country code required";
    if (!form.phoneNumber || !/^[0-9]{10}$/.test(form.phoneNumber))
      newErrors.phoneNumber = "Valid 10-digit phone number required";
    if (!form.country) newErrors.country = "Country is required";
    if (!form.city) newErrors.city = "City is required";
    if (!form.pan || !/[A-Z]{5}[0-9]{4}[A-Z]/.test(form.pan))
      newErrors.pan = "Valid PAN required (e.g. ABCDE1234F)";
    if (!form.aadhar || !/^[0-9]{12}$/.test(form.aadhar))
      newErrors.aadhar = "Valid 12-digit Aadhar required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      navigate("/success", { state: form });
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ maxWidth: "500px", margin: "auto" }}>
      <h2>User Registration</h2>

      {/* Inputs */}
      {[
        { name: "firstName", label: "First Name" },
        { name: "lastName", label: "Last Name" },
        { name: "username", label: "Username" },
        { name: "email", label: "Email", type: "email" },
        { name: "phoneCode", label: "Country Code" },
        { name: "phoneNumber", label: "Phone Number" },
        { name: "pan", label: "PAN No." },
        { name: "aadhar", label: "Aadhar No." }
      ].map(({ name, label, type = "text" }) => (
        <div key={name}>
          <label>{label}</label>
          <input
            name={name}
            type={type}
            value={form[name]}
            onChange={handleChange}
          />
          <div style={{ color: "red" }}>{errors[name]}</div>
        </div>
      ))}

      {/* Password */}
      <div>
        <label>Password</label>
        <input
          type={showPassword ? "text" : "password"}
          name="password"
          value={form.password}
          onChange={handleChange}
        />
        <button type="button" onClick={() => setShowPassword(!showPassword)}>
          {showPassword ? "Hide" : "Show"}
        </button>
        <div style={{ color: "red" }}>{errors.password}</div>
      </div>

      {/* Country */}
      <div>
        <label>Country</label>
        <select name="country" value={form.country} onChange={handleChange}>
          <option value="">--Select--</option>
          {Object.keys(countries).map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        <div style={{ color: "red" }}>{errors.country}</div>
      </div>

      {/* City */}
      <div>
        <label>City</label>
        <select name="city" value={form.city} onChange={handleChange}>
          <option value="">--Select--</option>
          {form.country &&
            countries[form.country].map((city) => (
              <option key={city} value={city}>
                {city}
              </option>
            ))}
        </select>
        <div style={{ color: "red" }}>{errors.city}</div>
      </div>

      {/* Submit */}
      <button type="submit">Submit</button>
    </form>
  );
}
